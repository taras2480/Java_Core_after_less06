/*
 * LOGOS It Academy Lesson_09_hw
 * enum Seasons
 * */



package ua.lgs.lviv.task1_3_enum_month;


public enum Seasons {
	SPRINT, SUMMER, AUTUMN, WINTER;
}


