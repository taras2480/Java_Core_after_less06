package ua.lgs.lviv.task1_3_enum_month;

public class WrongInputConsoleParametersException extends Exception {

	

	public WrongInputConsoleParametersException(String message) {
		System.out.println(message);
	}

	
	
	
	
	
	
}