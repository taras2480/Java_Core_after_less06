package ua.lgs.lviv.enum_exeption_docs_task1_3_3;

import java.util.Scanner;


import ua.lgs.lviv.task1_3_enum_month.WrongInputConsoleParametersException;

public class Application {

	public static void main(String[] args) throws WrongInputConsoleParametersException {
		
		double num1;
		double num2;
		Scanner sc = new Scanner(System.in);
		
		while (true) {
			switch (sc.next()) {
			
			
			case "1":{
		
		System.out.println("Enter two numerics");
		if (sc.hasNextInt()) {
			num1=sc.nextInt();
		} else {
			String message = "Wrong data";
			throw new WrongInputConsoleParametersException(message);
		}
		if (sc.hasNextInt()) {
			num2=sc.nextInt();
			System.out.println((num1+num2));
		} else {
			String message = "Wrong data";
			throw new WrongInputConsoleParametersException(message);
			
		}
			}
		}
	}
	}
}
