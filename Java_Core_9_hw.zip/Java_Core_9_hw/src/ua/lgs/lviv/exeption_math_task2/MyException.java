package ua.lgs.lviv.exeption_math_task2;

public class MyException extends Exception {

	public MyException(String message) {
		
		System.out.println(message);
	}
}
