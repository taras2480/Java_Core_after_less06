package ua.lgs.lviv.exeption_math_task2;

public class Main {
	public static void main(String[] args) throws IllegalAccessException, MyException {
	
		Methods m=new Methods(-6, 3);	
		m.division();
		m.summary();
		m.subtraction();
		m.multiplication();
		Methods m1=new Methods(1, 5);	
		m1.division();
		m1.summary();
		m1.subtraction();
		m1.multiplication();
		Methods m2=new Methods(3, -9);	
		m2.division();
		m2.summary();
		m2.subtraction();
		m2.multiplication();
		
	
	
	
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	
	
	
	
	
	
	
	

}
