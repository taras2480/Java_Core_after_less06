package ua.lgs.lviv.exeption_math_task2;

public class Methods {

	private static double a;
	private static double b;

	public Methods(double a, double b) {
		super();
		this.a = a;
		this.b = b;
	}

	double summary() throws MyException, IllegalAccessException {
		Methods.result();

		System.out.println(a + b);
		return a + b;

	}

	double subtraction() throws MyException, IllegalAccessException {
		Methods.result();
		System.out.println(a - b);

		return a - b;

	}

	double multiplication() throws MyException, IllegalAccessException {
		Methods.result();
		System.out.println(a * b);

		return a * b;

	}

	double division() throws MyException, IllegalAccessException {
		Methods.result();
		System.out.println(a / b);

		return a / b;

	}

	public static void result() throws MyException, IllegalAccessException {
		if (a < 0 & b < 0) {

			throw new IllegalArgumentException();
		}
		if (a == 0 && b != 0 || (a != 0 && b == 0)) {
			throw new ArithmeticException();
		}
		if (a == 0 && b == 0) {
			throw new IllegalAccessException();
		}

		if (a > 0 && b > 0) {
			
			String message="Wrong";
			throw new MyException(message);
		}

	}

}
