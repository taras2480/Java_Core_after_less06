package ua.lgs.lviv.task2_3_enum_numer;

import ua.lgs.lviv.task1_3_enum_month.WrongInputConsoleParametersException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws WrongInputConsoleParametersException {

		Scanner sc = new Scanner(System.in);

		while (true) {

			switch (sc.next()) {

			case "1": {
				System.out.println("Enter numeric");
				sc = new Scanner(System.in);
				Double num = sc.nextDouble();

				if (num % 2 == 0) {
					System.out.println("Number is even");
				} else if (num % 2 == 1) {

					System.out.println("Number is odd");
				}

				else {
					String message = "Wrong numeric";
					throw new WrongInputConsoleParametersException(message);
				}

				break;
			}

			}

		}

	}

}